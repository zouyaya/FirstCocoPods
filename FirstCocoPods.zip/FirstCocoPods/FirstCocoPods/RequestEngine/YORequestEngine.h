//
//  YORequestEngine.h
//  FirstCocoPods
//
//  Created by yangou on 2017/7/21.
//  Copyright © 2017年 yangou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"

typedef void (^BlockResponse)(NSURLSessionDataTask *task, id responseObject);
typedef void (^BlockResponseError)(NSURLSessionDataTask *task,NSError *error);
typedef void (^BlockDownload)(NSURL *targetPath,NSURLResponse *response);
typedef void (^BlockDownloadError)(NSURLResponse *response,NSURL *filePath,NSError *error);;
typedef void (^BlockUpload)(NSURLResponse *response,id responseObject);
typedef void (^BlockUploadError)(NSURLResponse *response,id responseObject,NSError *error);


@interface YORequestEngine : NSObject

+(AFHTTPSessionManager *)shareManager;

/**
 * get 请求，需要加载菊花和缓存的调用方法
 */
+ (void) requestByGetWithRequestURL:(NSString *)requesturl
                      andParameters:(NSDictionary *)parameters
                           andBlock:(BlockResponse) block
                      andBlockError:(BlockResponseError) errorBlock
                       andIsNeedHUD:(BOOL) isNeedHUD
                         andIsCache:(BOOL)isCache;

/**
 * get 请求，不需要加载菊花和缓存的调用方法
 */
+ (void) requestByGetWithRequestURL:(NSString *)requesturl
                      andParameters:(NSDictionary *)parameters
                           andBlock:(BlockResponse) block
                      andBlockError:(BlockResponseError) errorBlock;

/**
 * post 请求，需要加载菊花和缓存的调用方法
 */
+ (void) requestByPostWithRequestURL:(NSString *)requesturl
                       andParameters:(NSDictionary *)parameters
                            andBlock:(BlockResponse)block
                       andBlockError:(BlockResponseError)errorBlock
                        andIsNeedHUD:(BOOL)isNeedHUD
                          andIsCache:(BOOL)isCache;

/**
 * post 请求，不需要加载菊花和缓存的调用方法
 */
+ (void) requestByPostWithRequestURL:(NSString *)requesturl
                       andParameters:(NSDictionary *)parameters
                            andBlock:(BlockResponse)block
                       andBlockError:(BlockResponseError)errorBlock;

/**
 *从服务器下载数据
 */
+ (void) downloadFileWithRequestURL:(NSString *)requesturl
                           andBlock:(BlockDownload)block
                      andBlockError:(BlockDownloadError)errorBlock;

/**
 * 向服务器上传文件
 */
+ (void) uploadFileToServiceWithRequestURL:(NSString *)requesturl
                         andUploadFilePath:(NSString *)filePath
                                  andBlock:(BlockUpload)block
                             andBlockError:(BlockUploadError)blockError;
/**
 *向服务器上传二进制数据
 */
+ (void) uploadDataToServiceWithRequestURL:(NSString *)requesturl
                         andUploadFilePath:(NSString *)filePath
                                  andBlock:(BlockUpload)block
                             andBlockError:(BlockUploadError)blockError;
/**
 *获取多种网络请求的方法
 */
+ (void) requestWithMutiRequestWithRequestURL:(NSString *)requesturl
                            andWithParameters:(NSDictionary *)parameters
                 andConstructingBodyWithBlock:(void (^)(id<AFMultipartFormData>formatData))constructBlock
                                     andBlock:(BlockResponse)block
                                andBlockError:(BlockResponseError)blockError;
@end
