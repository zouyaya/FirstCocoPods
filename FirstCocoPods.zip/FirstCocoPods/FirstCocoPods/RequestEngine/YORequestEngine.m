//
//  YORequestEngine.m
//  FirstCocoPods
//
//  Created by yangou on 2017/7/21.
//  Copyright © 2017年 yangou. All rights reserved.
//

#import "YORequestEngine.h"
#import <MBProgressHUD.h>
#import "UIViewController+YOGetView.h"

@implementation YORequestEngine

+(AFHTTPSessionManager *)shareManager
{

    return [AFHTTPSessionManager manager];

}

+ (void)requestByGetWithRequestURL:(NSString *)requesturl
                     andParameters:(NSDictionary *)parameters
                          andBlock:(BlockResponse)block
                     andBlockError:(BlockResponseError)errorBlock
{


    [self requestByGetWithRequestURL:requesturl
                       andParameters:parameters
                            andBlock:block
                       andBlockError:errorBlock
                        andIsNeedHUD:NO
                          andIsCache:NO];


}

+(void)requestByGetWithRequestURL:(NSString *)requesturl
                    andParameters:(NSDictionary *)parameters
                         andBlock:(BlockResponse)block
                    andBlockError:(BlockResponseError)errorBlock
                     andIsNeedHUD:(BOOL)isNeedHUD andIsCache:(BOOL)isCache
{

   AFHTTPSessionManager *manager = [self requestBaseManager];
    if (isNeedHUD) {[MBProgressHUD showHUDAddedTo:[UIViewController currentViewController].view animated:YES];
    }
    [manager GET:requesturl
      parameters:parameters
        progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (isNeedHUD) {
            [MBProgressHUD hideAllHUDsForView:[UIViewController currentViewController].view animated:YES];
        }
        
       
        
       if (block != nil) {
            
             if ([responseObject isKindOfClass:[NSDictionary class]]) {
                block(task,responseObject);
            }else {
                NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
                block(task,dic);
            
            }
//
        }
//        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        if (isNeedHUD) {
            [MBProgressHUD hideAllHUDsForView:[UIViewController currentViewController].view animated:YES];
        }
        if (errorBlock != nil) {
            errorBlock(task,error);
        }
    }];
    

}

+(void)requestByPostWithRequestURL:(NSString *)requesturl andParameters:(NSDictionary *)parameters andBlock:(BlockResponse)block andBlockError:(BlockResponseError)errorBlock
{
    [self requestByPostWithRequestURL:requesturl
                        andParameters:parameters
                             andBlock:block
                        andBlockError:errorBlock
                         andIsNeedHUD:NO
                           andIsCache:NO];

}

+(void)requestByPostWithRequestURL:(NSString *)requesturl andParameters:(NSDictionary *)parameters andBlock:(BlockResponse)block andBlockError:(BlockResponseError)errorBlock andIsNeedHUD:(BOOL)isNeedHUD andIsCache:(BOOL)isCache
{
    AFHTTPSessionManager *manger = [self requestBaseManager];
    if (isNeedHUD) {
        [MBProgressHUD showHUDAddedTo:[UIViewController currentViewController].view animated:YES];
    }
    [manger POST:requesturl parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (isNeedHUD) {
            [MBProgressHUD hideAllHUDsForView:[UIViewController currentViewController].view animated:YES];
        }
        if (block != nil) {
            if ([responseObject isKindOfClass:[NSDictionary class]]) {
                block(task,responseObject);
            }else{
                NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
                block(task,dic);
                
            }
        }
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (isNeedHUD) {
            [MBProgressHUD hideAllHUDsForView:[UIViewController currentViewController].view animated:YES];
        }
        if (error != nil) {
            errorBlock(task,error);
        }
        
    }];
  



}

+(void)downloadFileWithRequestURL:(NSString *)requesturl andBlock:(BlockDownload)block andBlockError:(BlockDownloadError)errorBlock
{
    NSURLSessionConfiguration *configure = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc]initWithSessionConfiguration:configure];
    NSURL *URL = [NSURL URLWithString:requesturl];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
   
    NSURLSessionDownloadTask *task = [manager downloadTaskWithRequest:request progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        
        NSURL *documentsDirectoryURL = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory
                                                                              inDomain:NSUserDomainMask
                                                                     appropriateForURL:nil
                                                                                create:NO
                                                                                 error:nil];
        
       // DLog(@"suggestedFilename: %@", [response suggestedFilename]);
        
        return [documentsDirectoryURL URLByAppendingPathComponent:[response suggestedFilename]];
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        
    }];
    [task resume];


}


+(void)uploadFileToServiceWithRequestURL:(NSString *)requesturl andUploadFilePath:(NSString *)filePath andBlock:(BlockUpload)block andBlockError:(BlockUploadError)blockError
{


    NSURLSessionConfiguration *configure = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc]initWithSessionConfiguration:configure];
    NSURL *url = [NSURL URLWithString:requesturl];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    
    NSURL *filePathURL = [NSURL URLWithString:filePath];
    NSURLSessionUploadTask *uploadTask = [manager uploadTaskWithRequest:urlRequest fromFile:filePathURL progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
       
        if (error) {
            if (blockError != nil) {
                blockError(response,responseObject,error);
            }
            
        }else{
        
            if (block != nil) {
                block(response,responseObject);
            }
        }
        
    }];
    [uploadTask resume];

}

+(void)uploadDataToServiceWithRequestURL:(NSString *)requesturl andUploadFilePath:(NSString *)filePath andBlock:(BlockUpload)block andBlockError:(BlockUploadError)blockError
{
    NSURLSessionConfiguration *configure = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc]initWithSessionConfiguration:configure];
    NSURL *url = [NSURL URLWithString:requesturl];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    
    NSURL *dataURL = [NSURL URLWithString:filePath];
    
    NSData *fileData = [NSData dataWithContentsOfURL:dataURL];
    
    NSURLSessionUploadTask *uploadTask = [manager uploadTaskWithRequest:urlRequest fromData:fileData progress:nil completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
        
        if (error) {
            if (blockError != nil) {
                blockError(response,responseObject,error);
            }
            
        }else{
            
            if (block != nil) {
                block(response,responseObject);
            }
        }

    }];


    [uploadTask resume];

}

+ (void)requestWithMutiRequestWithRequestURL:(NSString *)requesturl andWithParameters:(NSDictionary *)parameters andConstructingBodyWithBlock:(void (^)(id<AFMultipartFormData>))constructBlock andBlock:(BlockResponse)block andBlockError:(BlockResponseError)blockError
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/plain", @"multipart/form-data", @"application/json", @"text/html", @"image/jpeg", @"image/png", @"application/octet-stream", @"text/json", nil];
    //设置cookies
    //    if ([KUserDefaults objectForKey:kUserDefaultsCookie]) {
    //        [TAPublicBaseManager setCookies];
    //    }
    
    [MBProgressHUD showHUDAddedTo:[UIViewController currentViewController].view animated:YES];
    
    [manager POST:requesturl parameters:parameters constructingBodyWithBlock:constructBlock progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        [MBProgressHUD hideAllHUDsForView:[UIViewController currentViewController].view animated:YES];
        if (block != nil) {
            block(task,responseObject);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        [MBProgressHUD hideAllHUDsForView:[UIViewController currentViewController].view animated:YES];
        if (blockError != nil) {
            blockError(task,error);
        }
    }];




}


+ (AFHTTPSessionManager *)requestBaseManager
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    return manager;

};

@end
