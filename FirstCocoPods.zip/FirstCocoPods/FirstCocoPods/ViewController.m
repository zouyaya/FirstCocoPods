//
//  ViewController.m
//  FirstCocoPods
//
//  Created by yangou on 2017/7/20.
//  Copyright © 2017年 yangou. All rights reserved.
//

#import "ViewController.h"
#import "Masonry.h"
#import "YORequestEngine.h"


@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *downBtn;
@property (strong, nonatomic) UIImageView *bottomImageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    _bottomImageView = [[UIImageView alloc]init];
    _bottomImageView.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:_bottomImageView];
    [_bottomImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view.mas_left);
        make.right.equalTo(self.view.mas_right);
        make.top.equalTo(_downBtn.mas_bottom);
        make.bottom.equalTo(self.view.mas_bottom);
    }];
    
    
    
}
- (IBAction)downWithImage:(id)sender {
    
    NSString *downUrl = @"http://image.baidu.com/search/detail?ct=503316480&z=undefined&tn=baiduimagedetail&ipn=d&word=%E7%BE%8E%E5%A5%B3%E5%9B%BE%E7%89%87&step_word=&ie=utf-8&in=&cl=2&lm=-1&st=undefined&cs=4293966912,134585640&os=1442641115,3139746515&simid=4271317272,688484936&pn=58&rn=1&di=145476162590&ln=3954&fr=&fmq=1500612918170_R&fm=&ic=undefined&s=undefined&se=&sme=&tab=0&width=undefined&height=undefined&face=undefined&is=0,0&istype=0&ist=&jit=&bdtype=0&spn=0&pi=0&gsm=0&hs=2&objurl=http%3A%2F%2Fpic31.photophoto.cn%2F20140417%2F0036036332651295_b.jpg&rpstart=0&rpnum=0&adpicid=0";
   // NSURL *url = [NSURL URLWithString:downUrl];
 
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    [YORequestEngine requestByGetWithRequestURL:downUrl andParameters:dic andBlock:^(NSURLSessionDataTask *task, id responseObject) {
        
        NSLog(@"%@",responseObject);
        
        NSLog(@"请求成功");
        
        
    } andBlockError:^(NSURLSessionDataTask *task, NSError *error) {
        
    } andIsNeedHUD:YES andIsCache:YES];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
