//
//  UIViewController+YOGetView.m
//  FirstCocoPods
//
//  Created by yangou on 2017/7/21.
//  Copyright © 2017年 yangou. All rights reserved.
//

#import "UIViewController+YOGetView.h"

@implementation UIViewController (YOGetView)


+ (UIViewController *) findTheBestControllerWithController:(UIViewController *)viewVC
{


    if (viewVC.presentedViewController) {
        
       
        return [UIViewController findTheBestControllerWithController:viewVC.presentedViewController];
        
    } else if ([viewVC isKindOfClass:[UISplitViewController class]]) {
        
        UISplitViewController* svc = (UISplitViewController*) viewVC;
        if (svc.viewControllers.count > 0)
            return [UIViewController findTheBestControllerWithController:svc.viewControllers.lastObject];
        else
            return viewVC;
        
    } else if ([viewVC isKindOfClass:[UINavigationController class]]) {
       
        UINavigationController* svc = (UINavigationController*) viewVC;
        if (svc.viewControllers.count > 0)
            return [UIViewController findTheBestControllerWithController:svc.topViewController];
        else
            return viewVC;
        
    } else if ([viewVC isKindOfClass:[UITabBarController class]]) {
        
        UITabBarController* svc = (UITabBarController*) viewVC;
        if (svc.viewControllers.count > 0)
            return [UIViewController findTheBestControllerWithController:svc.selectedViewController];
        else
            return viewVC;
        
    } else {
        
        return viewVC;
        
    }


}


+(UIViewController *)currentViewController{


    UIViewController *viewVC = [UIApplication sharedApplication].keyWindow.rootViewController;
    return [UIViewController findTheBestControllerWithController:viewVC];
}

@end
