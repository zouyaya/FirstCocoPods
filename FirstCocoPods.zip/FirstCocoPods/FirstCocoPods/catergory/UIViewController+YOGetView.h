//
//  UIViewController+YOGetView.h
//  FirstCocoPods
//
//  Created by yangou on 2017/7/21.
//  Copyright © 2017年 yangou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (YOGetView)

+(UIViewController *)currentViewController;

@end
